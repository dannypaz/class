#!/usr/bin/python
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import os

# Load the senators' names, parties, and voting records.
vote_matrix = np.loadtxt('vote_matrix.txt')
senators = [line.strip() for line in open('senators.txt').readlines()]
parties = [line.strip() for line in open('parties.txt').readlines()]
colors = [float(line.strip()) for line in open('color.txt').readlines()]
measures = [line.strip() for line in open('measures.txt').readlines()]
dem_index = [i for i in range(len(parties)) if parties[i] == 'D']
rep_index = [i for i in range(len(parties)) if parties[i] == 'R']
ind_index = [i for i in range(len(parties)) if parties[i] == 'I']

# Helper function for text
def PrintText(preamble, t):
  words = t.split()
  line = None
  for word in words:
    if not line:
      line = '  ' + preamble + word + ' '
    elif len(line) + len(word) < 80:
      line = line + word + ' '
    else:
      print(line)
      line = '    ' + word + ' '
  print(line)

# Let's create a concept of the current 'selection'
selection = [False] * len(senators)

fig = plt.figure()
ax = fig.add_subplot(111)

# Let's separate out the function to do PCA.
def DoPCA():
  global pc1, pc2, senators_pc1, senators_pc2
  if True in selection:
    indices = [i for i in range(len(selection)) if selection[i]]
  else:
    indices = range(len(selection))
  print('Computing PCA for %d senators' % len(indices))
  svd_u, svd_s, svd_v = np.linalg.svd(vote_matrix[indices,:])
  pc1 = np.squeeze(np.asarray(svd_v[1,:]))
  pc2 = np.squeeze(np.asarray(svd_v[2,:]))
  senators_pc1 = np.squeeze(np.asarray(np.dot(vote_matrix, pc1)))
  senators_pc2 = np.squeeze(np.asarray(np.dot(vote_matrix, pc2)))
  eps = 0.1
  plt.xlim([min(senators_pc1)-eps,max(senators_pc1)+eps])
  plt.ylim([min(senators_pc2)-eps,max(senators_pc2)+eps])

# And separate the function to do PCA
senators_artist = None
def UpdateSenators():
  global senators_artist
  if senators_artist:
    senators_artist.remove()
  ax.set_frame_on(False)
  ax.axes.get_yaxis().set_visible(False)
  ax.axes.get_xaxis().set_visible(False)
  senators_artist = ax.scatter(
      senators_pc1, senators_pc2, c=colors,
      s=25,###
      zorder=1, ###
      picker=5, ###
      cmap='hsv',
      norm=matplotlib.colors.Normalize(vmin=0, vmax=1),
      edgecolors='none')

# Add a a way of hilighting a selection
selection_artist = None
def UpdateSelection():
  global selection_artist
  if selection_artist:
    selection_artist.remove()
  selection_artist = ax.scatter(
      [senators_pc1[i] for i in range(len(senators)) if selection[i]],
      [senators_pc2[i] for i in range(len(senators)) if selection[i]],
      c='pink',
      s=255,
      zorder=0,
      edgecolors='none')

def ResetSelection():
  print('Reset selection')
  global selection
  selection = [False] * len(senators)

# Hook up the pick event
def on_pick(event):
  if senators_artist == event.artist:
    for index in event.ind:
      print(senators[index])
fig.canvas.mpl_connect('pick_event', on_pick)

def OnMouseSelect(x, y, w, h):
  x_min = min(x, x+w)
  x_max = max(x, x+w)
  y_min = min(y, y+h)
  y_max = max(y, y+h)
  need_redraw = False
  for i in range(len(selection)):
    x, y = senators_pc1[i], senators_pc2[i]
    if x_min <= x and x <= x_max and y_min <= y and y <= y_max:
      if not selection[i]:
        if not need_redraw:
          print('Selected:')
          need_redraw = True
        selection[i] = True
        print('  %s (index %d)' % (str(senators[i]), i))
  if need_redraw:
    UpdateSelection()

# Selector next
import mouseselector
mouse_selector = mouseselector.MouseSelector(fig, ax, OnMouseSelect)

def PrintMeasures(axis, axis_name):
  indices = np.abs(axis).argsort()
  print('The +%s direction will:' % axis_name)
  for ii in range(1,15):
    i = indices[-ii]
    if axis[i] < 0:
      PrintText('OPPOSE: ', measures[i])
    else:
      PrintText('SUPPORT: ', measures[i])

def on_key(event):
  if event.key == 'r':
    ResetSelection()
    UpdateSelection()
    ax.figure.canvas.draw()
  if event.key == 'a':
    DoPCA()
    UpdateSenators()
    UpdateSelection()
    ax.autoscale_view()
    ax.figure.canvas.draw()
  if event.key == 'x':
    PrintMeasures(pc1, 'x')
  if event.key == 'y':
    PrintMeasures(pc2, 'y')
  if event.key == 'z':
    for i in range(len(selection)):
      if selection[i]:
        print(vote_matrix[i,:])
  return False
fig.canvas.mpl_connect('key_press_event', on_key)


DoPCA()
UpdateSenators()
UpdateSelection()
plt.show()
quit()
