import matplotlib
import matplotlib.pyplot as plt

class MouseSelector():
  def __init__(self, fig, ax, callback):
    self.ax = ax
    self.callback = callback
    self.button_down = False
    self.rect = matplotlib.patches.Rectangle(
      (0,0), 0, 0,
      edgecolor='black',
      facecolor='None',
      linestyle='dashed')
    self.ax.add_patch(self.rect)
    self.x = 0
    self.y = 0
    self.w = 0
    self.h = 0
    self.UpdateRect()
    self.connections = []
    self.connections.append(
        fig.canvas.mpl_connect('button_press_event', self.on_press))
    self.connections.append(
        fig.canvas.mpl_connect('button_release_event', self.on_release))
    self.connections.append(
        fig.canvas.mpl_connect('motion_notify_event', self.on_motion))
  def UpdateRect(self):
      self.rect.set_width(self.w)
      self.rect.set_height(self.h)
      self.rect.set_xy((self.x, self.y))
      self.rect.set_visible(self.w or self.h)
      self.ax.figure.canvas.draw()
  def on_press(self, event):
    if event.inaxes == self.ax:
      self.button_down = True
      self.x = event.xdata
      self.y = event.ydata;
      self.w = 0;
      self.h = 0
      self.UpdateRect()
  def on_motion(self, event):
    if event.inaxes == self.ax and self.button_down:
      self.w = event.xdata - self.x
      self.h = event.ydata - self.y
      self.UpdateRect()
  def on_release(self, event):
    self.callback(self.x, self.y, self.w, self.h)
    self.w = 0
    self.h = 0
    self.UpdateRect()
    self.button_down = False
