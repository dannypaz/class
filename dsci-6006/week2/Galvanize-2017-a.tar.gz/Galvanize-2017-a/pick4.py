#!/usr/bin/python
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

# Create some data.
x = np.random.normal(0, 1, 250);
y = np.random.normal(0, 1, 250);

# Create a figure and show it.
fig = plt.figure()
plt.scatter(x, y, picker=5)

# http://matplotlib.org/api/backend_bases_api.html#matplotlib.backend_bases.FigureCanvasBase.mpl_connect
def MyFunctionToCallWhenAButtonIsPressed(event):
  print('A Button Press Event Happened!')
  print('  The click was at (%f, %f)' % (event.xdata, event.ydata))

# Connect the "button_press_event" to this function
fig.canvas.mpl_connect('button_press_event', MyFunctionToCallWhenAButtonIsPressed)

# http://matplotlib.org/api/backend_bases_api.html#matplotlib.backend_bases.PickEvent
def MyFunctionToCallWhenSomethingIsPicked(event):
  print('A pick event happened!')
  print('  It touched indices %s' % (str(event.ind)))
  for i in event.ind:
    print('    %d: (%f, %f)' % (i, x[i], y[i]))

# Connect the "pick_event" to this function
fig.canvas.mpl_connect('pick_event', MyFunctionToCallWhenSomethingIsPicked)

# Show the plot.
print("I'm about to call plt.show()")
plt.show()
print("plt.show() has finished")
