#!/usr/bin/python
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

# Create some data.
x = np.random.normal(0, 1, 250);
y = np.random.normal(0, 1, 250);

# Create a figure and show it.
plt.scatter(x, y)
print("I'm about to call plt.show()")
plt.show()
print("plt.show() has finished")
